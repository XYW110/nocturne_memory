---
name: Snow App
surface: web
---

# Snow App Design System

> A calm, monochrome-first desktop design language: floating islands of translucent white on a pale gray-blue base. Reverse-engineered from [MayDay-wpf/snow-app](https://github.com/MayDay-wpf/snow-app) and production-validated by a full frontend restyle. The single mental model: **one flat canvas, everything else floats on it as a rounded island.**

- Page background: #eef2f7
- Heading: #111827
- Accent: #111827
- Muted: #6b7280

## Visual Theme

- The entire viewport is a **flat, edge-to-edge base** of pale gray-blue `#eef2f7` (light) or near-black `#050505` (dark). Nothing but the base ever touches the window edges.
- All content lives on **islands**: independent rounded cards with a translucent surface (`rgba(255,255,255,0.78)` in light), a soft two-part shadow, and a 1px inner top highlight that reads as paper catching light.
- The overall feeling is Notion/Linear-adjacent: quiet, airy, restrained. Visual noise comes from structure (islands, gaps, type hierarchy), not from color or decoration. If a screen feels busy, remove color and shadow before removing content.
- Depth is expressed exactly twice per island — one soft drop shadow, one inner highlight — and never stacked.

## Layout: Floating Islands

- **Outer margins and gaps between every island are exactly 10px** (`--gap-island`). This uniform gutter is the strongest identifying feature of the style.
- The top bar is **three separate small islands** (brand cluster, nav cluster, action cluster) that visually align with the content columns below via CSS grid.
- Content areas are **independent island cards** arranged on a grid (e.g. list column ~280–300px, main content flexible, detail panel ~340–380px). Islands never touch each other or the viewport edge.
- Full-height islands use internal scroll (`overflow: hidden` on the island, `overflow-y: auto` on an inner region) — the page itself never scrolls; the app feels like a desktop.
- Small floating elements (popovers, drawers, rails) may sit above islands; only these may use backdrop blur.

## Responsive & Device Adaptation (desktop / tablet / mobile)

The desktop three-island layout is the reference; smaller viewports adapt by **collapsing columns and condensing chrome, never by restyling components**. Islands keep their radius, shadow, surface, and type at every size. Breakpoints are ported from snow-app's actual media queries (920 / 820 / 720 / 640px tiers).

- **Wide desktop ≥1440px**: the content column is clamped (`--content-max`: 860px @1024 → 1000px @1280 → 1120px @1440 → 1240px @1920 → 1400px @2560) so islands stay centered and readable; the base canvas keeps growing, the content doesn't.
- **Desktop 1024–1439px**: full three-island layout, 10px `--gap-island`, all panels visible, internal island scrolling.
- **Tablet landscape / small desktop 721–1023px**: the right detail panel collapses into a slide-over (tap a row to open it as an overlay island); layout becomes nav + main. In the **641–860px band the top bar wraps to two rows** (row 1: brand + namespace + settings; row 2: centered nav tabs) — a one-row bar measurably overflows by ~130px at 730px once the namespace selector returns. Top bar islands may merge into two clusters.
- **Phablet ≤720px**: top bar condenses — cluster gap 6px, padding 0 10px, secondary labels (branch/subtitle text) hidden; `--gap-island` drops to **8px**; side panels are collapsed by default.
- **Mobile ≤640px**: everything stacks to a **single column**; modals become near-full-bleed sheets (12px viewport inset, full width/height); toolbar rows go vertical; tab bars shrink padding (0 8px) and scroll horizontally when overflowing; islands switch from internal scroll to **page scroll**; column resizers are hidden.
- **Touch (`pointer: coarse`)**: `--tap-target` raises the minimum interactive height (32px desktop → 36px @≤720 → 40px @≤640 → 44px on touch). Rows, buttons, and nav pills must honor it; font sizes stay as-is (13px remains legible) but never shrink further on mobile.
- **Reduced motion**: `prefers-reduced-motion: reduce` disables transitions (`--transition-fast: 0s`) — snow-app ships the same behavior.
- Informational breakpoint tokens `--bp-tablet: 1024px`, `--bp-phablet: 720px`, `--bp-mobile: 640px` document the tiers; media queries must use literal values since CSS vars don't resolve inside `@media`.

## Field-Tested Responsive Patterns (production pitfalls)

Rules below were validated by shipping a full app through 360–2560px testing. Each exists because its absence caused a real defect.

### Fixed-width starvation

Never let a fixed-width element (`w-72` search, `w-40` select, `w-[600px]` drawer) share one flex row with flexible siblings at ≤640px. The flexible sibling starves: a 288px fixed search squeezed a path picker to **25px wide**. Fix: stack the header into full-width rows (picker row, then search row) and drop fixed widths (`w-72` → `w-full` at ≤640px).

### Drawers & modals become sheets

A fixed 600px right-anchored drawer overflows narrow viewports catastrophically (left edge at **-218px** at 390px). At ≤640px: `inset 12px` on all sides, `width/height auto` (fill the inset), `radius-xl`, slide up from bottom instead of from the right. Desktop keeps the docked panel.

### Detail headers stack, action bars stay single-line

At ≤640px a detail header (title block + action buttons) must wrap into two rows: title/meta row, then a right-aligned action row. Buttons and meta pills get `whitespace-nowrap` — without it, CJK button labels stack one character per line ("拒/绝/组"). Long identifiers (URIs, node paths) get `break-all` on mobile; every flex child containing them needs `min-w-0`.

### Navigation pattern swap, not strip polish

Horizontal breadcrumb strips fail on mobile: 25px tap targets, invisible horizontal scroll behind a fade mask, current crumb off-screen. Don't polish the strip — **replace the pattern at ≤640px** with a native `<select>` path picker (controlled value = current path, options = trail levels, onChange navigates). The OS picker is the best mobile affordance; the styled strip remains for ≥641px with auto-scroll to the current crumb (`scrollLeft = scrollWidth` on change) and 40px `--tap-target` heights.

### Grid collapse: drop col-spans

When collapsing a multi-column grid to one column at ≤640px, remove any `col-span-N` from children. A `col-span-3` inside a 1-column grid forces implicit columns and silently re-sidelines stacked rows.

### Overflow audit protocol (do this before shipping responsive work)

Sweep real device widths — at minimum **360 / 390 / 412 / 436 / 730 / 1280px** — and assert no element's `getBoundingClientRect().right > innerWidth`. Visual review alone misses overflow (e.g. a settings button poking 21px past the viewport looked "mostly fine" in a screenshot). Also: palette-residue audits must cover `.html` and `.js` files, not only `.jsx` — a hard-coded `bg-slate-900` on `<body>` in index.html once shadowed every theme and preset.

### Theme wiring lives in one module

All theme/preset attribute mutation (`data-theme`, `data-preset` on `documentElement`) belongs in a single theme module (localStorage-backed, invalid values fall back to defaults); never set the attributes ad hoc in components. Ensure nothing hard-codes base colors on `<body>`/`<html>` — they mask presets and dark mode.

## Color

- **Monochrome-first**: the accent color *is* the primary text color (`#111827` in light, `#58a6ff` in dark). Buttons, active nav states, toggles, and selection indicators are near-black/gray — never a brand hue.
- Text is a strict **four-step gray ladder**: primary `#111827` → secondary `#374151` → muted `#6b7280` → faint `#9ca3af` (inverted in dark: `#f3f4f6` → `#d1d5db` → `#9ca3af` → `#6b7280`). Never invent intermediate grays.
- **Semantic colors are status-only** and always appear as *light-background + dark-foreground pills*: success `#dcfce7/#166534`, danger `#fee2e2/#991b1b`, warning `#fef3c7/#92400e`, info `#dbeafe/#1e40af`. A colored pill may label a state; it may never fill a panel, border a card, or tint a background area.
- Dark theme is **pure neutral black** (`#050505` base; surfaces `#0a0a0a`/`#111111`/`#1a1a1a`), not a darkened blue. In dark mode the accent becomes GitHub-style `#58a6ff` and semantic pills use deep-tinted backgrounds with bright foregrounds.
- Borders are barely-there: `rgba(15,23,42,0.08)` in light (`rgba(255,255,255,0.08)` in dark).

## Typography

- Small, dense, utilitarian: **base 13px, most UI text 10–13px**, titles 15px. Line-height 1.4–1.7.
- System font stack (`-apple-system, "Segoe UI", ...`); monospace (`"SF Mono", "Fira Code", Consolas`) for diffs and code.
- **All numbers, counts, timestamps, and sizes use `tabular-nums`** — this is non-negotiable in data-dense UIs.
- Weight carries hierarchy instead of size: 500 for body labels, 600 for island headers, 700 only for the brand name. Avoid bold body text.
- Letter-spacing stays near-default; slightly tight (`-0.01em`) on island headers, uppercase + `0.05em` only for settings group labels.

## Components

- **Island**: `--surface` background, `--radius-xl` (16px), `--island-shadow`, 1px `--border`. Optional island header (12px/600, padded 14px 18px 10px).
- **Nav tab**: pill of 12px text; inactive = muted text, hover = `--surface-hover`; active = near-black pill with white text.
- **Buttons**: primary = `--accent` bg + white text (hover: slight brightness/opacity shift); ghost = transparent, muted text, hover `--surface-hover`; danger-text = semantic danger fg on transparent, hover danger bg; icon button = 32px square, radius-md.
- **Pills**: fully rounded (99px), 10px/600 text, 2px 8px padding, semantic bg/fg pairs only.
- **Chips**: radius-sm, 11px/500, for domains/namespaces — neutral (`--surface-hover` bg) or info pair.
- **List rows** (queues, trees): radius-md rows with 10px padding; hover = `--surface-hover`; selected = `--surface-hover` + 3px `--accent` left border.
- **Detail panel**: island split into header (title 15px/600 + meta row of chips, dots, `tabular-nums` facts), body, and a footer action bar with primary approve + danger-text reject.
- **Timeline**: 8px semantic-colored dots connected by 1px `--border` lines, with 10px `tabular-nums` timestamps.
- **Toggle**: 36×20px track, `--accent` when on. **Select/input**: radius-md, 1px border, focus = `--focus-ring` + accent border.

## Radius, Elevation & Gaps

- Radius ladder strictly **6 / 8 / 12 / 16px** (`--radius-sm/md/lg/xl`): chips 6, inputs/buttons/rows 8, nested cards 12, islands/panels 16. Pills are fully round.
- Elevation is a two-level system: `--island-shadow` (0 14px 34px @ 6% + inner top highlight) for islands, `--island-shadow-soft` for nested/hover-quiescent cards. Hover raises shadow intensity slightly, never scales or translates the island.
- The only allowed spacing rhythm for outer gaps is **10px**; internal component padding is 10/14/18/22px.

## Motion & Interaction

- Transitions: `0.15s ease` for color/background/shadow only. No springs, no bounces, no slide-in animations.
- Hover feedback is a **background tint change** (`--surface-hover`) — not elevation jumps, not underlines.
- Focus is keyboard-visible via a 6%-alpha accent ring (`--focus-ring`), used identically on inputs, rows, and buttons.
- Selection uses the accent left-border + hover tint (never a solid accent fill over content rows).

## Iconography

- Lucide (16px, stroke ~1.5–2px) or equivalent line icons; inline SVG is fine. Icons inherit text color — no colored icons except inside semantic pills. One icon per control, never decorative icon rows.

## Accessibility

- Four-step text grays are fixed; never place faint text on tinted backgrounds. Body text must be primary or secondary.
- All semantic pills pair a light bg with a dark fg of the same hue family — keep that pairing when adding new semantic states; verify ≥ 4.5:1 contrast for pill text.
- Every interactive element has a visible focus ring; `role`/`aria-checked` on toggles; keyboard navigation on list rows.
- Dark theme is not an inversion afterthought: check that translucent surfaces become opaque (`#0a0a0a`) and shadows deepen, since inner highlights flip to 4% white.

## Performance & Implementation Notes

- **No large-area glassmorphism**: backdrop blur on full panels is deliberately banned (macOS compositor CPU cost, learned from snow-app). Blur (`blur(18px) saturate(1.16)`) is reserved for small floating elements only.
- Islands keep layout cost low: opaque-enough surfaces, no nested filters, shadows via `box-shadow` only.
- Tokens are CSS variables on `:root`, theme-switched via `[data-theme="dark"]` on the document root; components consume tokens through utility classes (e.g. Tailwind arbitrary values `bg-[var(--surface)]`) rather than hard-coded values.

## Theme Presets

- The system ships **12 theme presets** ported 1:1 from snow-app's `THEME_PRESETS` registry: Snow (default), Midnight Blue, Forest Green, Rose Pink, Solarized, Nord, Dracula, Tokyo Night, GitHub, Google, Gruvbox, Cream.
- **Structure never changes across presets** — islands, radii, shadows, spacing, typography, and all component rules stay identical; only the palette swaps. This is the same contract snow-app uses.
- Presets are selected with a `data-preset="<id>"` attribute on the document root and **compose with** `data-theme="dark"` (e.g. `[data-preset="nord"][data-theme="dark"]`). `snow` is the default and has no override block.
- Preset blocks in `tokens.css` only override fields that differ from the Snow baseline; everything else inherits. `--semantic-warning-*` is not part of snow-app palettes and keeps the Snow defaults in every preset.
- Preset palettes additionally expose optional tokens not present in the base set: `--surface-active` (pressed/active bg), `--surface-chrome` (top-bar chrome bg), `--selection-bg` (text selection). Use them when available, fall back to `--surface-hover` / `--accent` otherwise.
- Custom accent colors (snow-app's `ThemeColorEditor`) are a runtime overlay: set `--accent` and `--accent-contrast` inline, never by editing preset blocks.

## Anti-patterns

- Full-bleed panels touching window edges; colored sidebars; brand-hue buttons or links.
- Amber/emerald/red **text or borders** used decoratively — semantic colors appear only inside pills (and diff line backgrounds).
- Glassmorphism panels, neon gradients, glow shadows, large border radii (>16px), oversized headings (>16px), springy animations.
- Hard-coded hex values in components instead of tokens; inventing a fifth gray; mixing gutter widths (anything but 10px between islands).
- Modal scrims with heavy blur; hover states that move or scale islands.
