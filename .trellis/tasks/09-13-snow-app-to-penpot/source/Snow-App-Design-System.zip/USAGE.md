# Snow App — Usage Guide

How agents should consume this design system when generating UI.

## Token consumption

- `tokens.css` is the single source of truth. Reference variables — never hard-code palette values in generated markup (the only sanctioned literals: preview swatches inside a theme-picker component).
- Utility-class projects (Tailwind): consume via arbitrary values — `bg-[var(--surface)]`, `text-[var(--text-primary)]`, `rounded-[var(--radius-xl)]`, `shadow-[var(--island-shadow)]`, `border-[var(--border)]`, `min-h-[var(--tap-target)]`, `max-w-[var(--content-max)]`.
- Plain-CSS projects: use the semantic class vocabulary from `components.html` (island, pill-*, chip-*, nav-tab, btn-*) backed by the same variables.

## Responsive rules (literal breakpoints — vars don't work inside @media)

| Band | Behavior |
|---|---|
| ≥2560px | content clamp 1400px |
| 641–1023px | tablet: side panels collapse to slide-overs; 641–860px top bar wraps to two rows (nav centered below) |
| ≤720px | `--gap-island` 8px; side panels collapsed |
| ≤640px | single column; page scroll; drawers/modals → 12px-inset sheets; **swap horizontal breadcrumb strips for native select pickers**; stack detail headers (title row / action row) |
| `pointer: coarse` | honor `--tap-target` (44px) |

Use stacked Tailwind arbitrary variants for band-specific rules: `max-[860px]:min-[641px]:flex-wrap`.

## Theming

- Light is default (`:root`). Dark = `data-theme="dark"` on the document root. Presets = `data-preset="<id>"` (12 ids; `snow` = default, no block). They compose: `[data-preset="nord"][data-theme="dark"]`.
- All theme/preset attribute writes belong in ONE theme module (localStorage-backed, invalid → fallback). Nothing may hard-code base colors on `<body>`/`<html>` — it masks presets and dark mode.

## Before shipping (checklist)

1. Overflow sweep at 360 / 390 / 412 / 436 / 730 / 1280px — no element may extend past the viewport.
2. Palette-residue grep (`slate-|indigo-|emerald-|amber-|red-|rose-|sky-`) across `.jsx` **and** `.html`/`.js` — must be 0.
3. Every `var(--x)` used is defined in tokens.css.
4. Semantic colors appear only as pills (light-bg + dark-fg pairs) — plus diff line backgrounds.
5. Tap targets honor `--tap-target`; `prefers-reduced-motion` respected.
