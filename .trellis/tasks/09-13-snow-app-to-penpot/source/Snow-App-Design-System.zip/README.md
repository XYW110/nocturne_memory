# Snow App Design System

A reusable OpenDesign package for Snow App Design System.

## Product Overview

A calm, monochrome-first desktop design language: floating islands of translucent white on a pale gray-blue base. Reverse-engineered from [MayDay-wpf/snow-app](https://github.com/MayDay-wpf/snow-app) and production-validated by a full front This design-system package is designed for product, app, workspace, and platform surfaces that need a reusable visual direction rather than a one-off mockup. It provides a concrete token layer, focused preview cards, and an applied UI kit so future agents can build interfaces with the same hierarchy, density, component roles, and interaction rules captured in DESIGN.md.

## Package Overview

- Category: Custom
- Surface: web
- Primary accent: #111827
- Background: #eef2f7
- Foreground: #111827

## Captured Foundations

- Visual Theme
- Layout: Floating Islands
- Responsive & Device Adaptation (desktop / tablet / mobile)
- Field-Tested Responsive Patterns (production pitfalls)
- Color
- Typography
- Components
- Radius, Elevation & Gaps

## Generated Files

- DESIGN.md: canonical design system source.
- colors_and_type.css: reusable CSS variables for color and type.
- preview/: focused HTML review cards for color themes, typography, spacing, components, and brand assets.
- assets/: logo and brand asset references.
- context/: structured source context captured during setup.
- ui_kits/app/: applied interface preview and UI-kit notes.
- SKILL.md: agent-facing usage instructions.

